package com.bank.service;

public interface RbiBank {

	public void createAccount();
	public void deposite();
	public void withdrawl();
	public void check_balance();
	public void deleteAccount();
}
